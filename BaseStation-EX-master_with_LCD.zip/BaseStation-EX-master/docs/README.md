This folder holds documents for our web page and our default files:
CONTRIBUTING.md
